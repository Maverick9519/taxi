# Основний бекенд (production-ready код)
# Твій код тут
